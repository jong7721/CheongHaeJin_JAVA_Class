

class Driver {
	public void drive(Vehicle vehicle) {
		vehicle.run();
	}
	
	/*
	public void driveTaxi(Taxi taxi) {
		taxi.run();
	}
	
	public void driveBus(Bus bus) {
		bus.run();
	}
	*/
}




public class ExRun {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Driver driver = new Driver();
		
		Taxi taxi = new Taxi();
		Bus bus = new Bus();
		
		
		driver.drive(taxi);
		driver.drive(bus);
		
	}

}

