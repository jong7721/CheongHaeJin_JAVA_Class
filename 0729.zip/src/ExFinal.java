
final class Parent {
	
	int a =10;
	final int b = 20;
	
	public void print() {
		System.out.printf("a: %d, b: %d \n", this.a, this.b);
	}
	
	public final void printFinal( ) {
		System.out.println("final method");
	}	
}


class Child extends Parent {
	
	public void printFinal() {
		
	}
}


public class ExFinal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Child c = new Child();
		
		c.print();
		c.printFinal();
	}

}
