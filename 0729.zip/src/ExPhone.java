
public class ExPhone {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		
		
		SmartPhone sp = new SmartPhone("ȫ�浿");
		
		sp.turnOn();
		sp.turnOff();
		
		DmbPhone dp = new DmbPhone("��ö��");
		dp.turnOn();
		dp.turnOff();
	}

}
