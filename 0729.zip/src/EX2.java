class Test {
	String name = null;
	int a = 0;
	static int b = 0;
	
	public Test(int a, int b) {
		this.name = "Test" + a;
		this.a = a;
		Test.b= b;
	}
	
	public void print( ) {
		System.out.printf("[%s] a: %d , b: %d \n", this.name, this.a, Test.b);
	}
}


public class EX2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 0;
		int b = 0;
		
		Test.b = 10;
		
		Test t1 = new Test(++a, ++b);				
		t1.print();
		
		
		Test t2 = new Test(++a, ++b);		
		t2.print();
		
		Test t3 = new Test(++a, ++b);		
		t3.print();
		
		
		System.out.println("<��Ȯ��>");
		t1.print();
		t2.print();
		t3.print();
		
		
		
	}

}
