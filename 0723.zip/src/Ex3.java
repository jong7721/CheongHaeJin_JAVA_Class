
public class Ex3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] array = {1,5,3,8,2};
		int max = 0;
		
		for(int i=0; i<array.length; i++) {
			
			if( max > array[i]) 
			{
				System.out.printf("intdex: %d, currentMax: %d \n", i, max);
				continue;
			}
			else
				max = array[i];
			
		System.out.printf("intdex: %d, currentMax: %d \n", i, max);	
		// �߰��� ���� ����� ��� �Ǵ��� Ȯ��
		
		}
		
		
		System.out.println("�ִ밪��: " + max );
		
	}

}
