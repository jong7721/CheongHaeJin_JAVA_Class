
class CharChange {
	char[] arrChar = null;
	
	public CharChange(String str) {
		this.arrChar = str.toCharArray();
	}
	
	public void printArrChar() {
		System.out.printf("chars in array: ");
		//���� for��
		for(char ch : arrChar) {
			System.out.printf("%c", ch);
		}
		System.out.println();
	}
	
	// to Uppercase
	public void toUpperCase() {

		System.out.print(">�빮�� ��ȯ: ");
		for(int i=0; i<arrChar.length ;i++) {
			if(arrChar[i] >= 'a' && arrChar[i] <='z')
				System.out.printf("%c", arrChar[i]-32);
			else
				System.out.printf("%c",arrChar[i]);
		}
		System.out.println();
	}
	
	// to lowercase
	public void toLowerCase() {
		System.out.print(">�ҹ��� ��ȯ: ");
		for(int i=0; i<arrChar.length ;i++) {
			if(arrChar[i] >= 'A' && arrChar[i] <='Z')
				System.out.printf("%c", arrChar[i]+32);
			else
				System.out.printf("%c",arrChar[i]);
		}
		System.out.println();
		
	}

}

public class ExCharChange {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		CharChange ch = new CharChange("Hello JaVa 14.0 sdK. aHa!");
		
		ch.printArrChar();
		
		ch.toUpperCase();
		ch.toLowerCase();
		
		//System.out.printf("\na to A: %c\n", ((int)'a')-32);
		
		String str1 = "Hello JaVa 14.0 sdK. aHa!";
		
		System.out.println(str1.toLowerCase());
		System.out.println(str1.toUpperCase());
		
		
	}

}
