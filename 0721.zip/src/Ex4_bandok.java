
public class Ex4_bandok {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 0;
		
		while(true)
		{
			if (num>10)
				break;
			
			if(++num%2 == 0)
				continue;
			else
				System.out.println(num);
			
			System.out.println("Ȧ�� ���");
			
		}
		
		
		
	}

}
