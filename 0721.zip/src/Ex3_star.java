
public class Ex3_star {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		final int N = 10;
		
		
		// 
		for (int j=0 ; j<N ; j++)
		{
			System.out.printf("%2d ", j+1);
			
			for(int i=0; i<j+1 ;i++)
				System.out.print("*");

			System.out.println(" ");
		}
		
		for (int j=0 ; j<N ; j++)
		{
			System.out.printf("%2d ", j+1);
			
			for(int sp=0; sp < N-(j+1) ; sp++)
				System.out.print(" ");
			
			for(int i=0; i<j+1 ;i++)
				System.out.print("*");

			System.out.println(" ");
		}
		
		for (int j=0 ; j<N ; j++)
		{
			System.out.printf("%2d ", j+1);
			
			for(int sp=0; sp < N-(j+1) ; sp++)
				System.out.print(" ");
			
			for(int i=0; i< ((2*j)+1) ;i++)
				System.out.print("*");

			System.out.println(" ");
		}
		
	}

}
