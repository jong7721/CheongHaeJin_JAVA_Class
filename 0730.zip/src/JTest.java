
public class JTest implements MyInterface {

	@Override
	public int getNum() {
		// TODO Auto-generated method stub
		return JTest.a;
	}

	
}
