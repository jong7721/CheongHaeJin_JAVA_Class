
class Animal {}

class Dog extends Animal {}

class Cat extends Animal {}

public class ExException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Animal animal = null;
		
		animal = new Dog();
		changeDog(animal);
		
		animal = new Cat();
		changeDog(animal);// ���⼭ ���� �߻�
		
	}

	public static void changeDog(Animal animal) {
		Dog dog = (Dog)animal;// ���⼭ ���� �߻� Class cast Exception
				
	}
	
	
}
