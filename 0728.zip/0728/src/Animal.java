
public class Animal {

	int age;
	String name;
	String hairColor;
	boolean hasTail;
	
	public void eat(String food) {
		
	}
	
	public Animal(String name) {
		this.name = name;
	}
	
	


	public void cry() {
		System.out.println("�ϰ� ������´�.");
		
	}

	
	
}
