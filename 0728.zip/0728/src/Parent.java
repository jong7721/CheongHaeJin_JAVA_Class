
public class Parent {

	int a = 10;
	int b = 20;

	String name = "Parent";
	
	public Parent() {
		System.out.println("Parent() ȣ���");
	}
	
	
	public void print() {
		System.out.printf("��ü: %s \na: %d \nb: %d\n",
				this.name,this.a,this.b);
	}
	
	
	
}
